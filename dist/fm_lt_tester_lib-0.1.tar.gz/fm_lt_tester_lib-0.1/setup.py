from setuptools import setup

setup(name = 'fm_lt_tester_lib',
    version = '0.1',
    description = "WH Modules",
    packages = ['fm_lt_tester_lib'],
    zip_safe = False,
)