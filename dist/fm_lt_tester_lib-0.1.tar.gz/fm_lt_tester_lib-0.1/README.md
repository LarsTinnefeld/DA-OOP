# Object oriented programming

This repository contains excercises applied to warehouse systems.
